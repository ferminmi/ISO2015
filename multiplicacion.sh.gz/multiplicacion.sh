#!/bin/bash

echo "Se multiplicara $1 y $2"
resultado=`expr $1 \* $2` > resul
clear

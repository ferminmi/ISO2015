#!/bin/bash

	num=1
	for parametro in $*
	do	
		echo "entre"	
		if [ `expr $num \% 2` -eq 1 ]; then
			if [ -f $parametro ] || [ -d $parametro ]; then
				echo "El archivo o directorio existe en el sistema"
			else
				echo "El archivo o directorio no existe en el sistema"
			fi
		fi
		num=`expr $num + 1`	
	done
